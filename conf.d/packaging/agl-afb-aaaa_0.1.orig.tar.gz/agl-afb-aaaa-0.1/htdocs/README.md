------------------------------------------------------------------------
   Basic HTML & WS test
------------------------------------------------------------------------

  # Load bindings directly from development tree for debug
  afb-daemon --verbose --verbose --token="" --ldpaths=build --port=1234 --roothttp=htdocs

