AFB Utilities
=============

You should find useful utilities to integrates as submodule in your bindings
development.

From your AFB apps repository do the following to integrates this repo:

```bash
git submodule add git@github.com:iotbzh/afb-utilities
```
