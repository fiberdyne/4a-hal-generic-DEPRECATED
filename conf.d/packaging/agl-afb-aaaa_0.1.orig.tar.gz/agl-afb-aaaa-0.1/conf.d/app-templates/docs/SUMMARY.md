# Summary

* [Document revisions](0-Doc-Revisions.md)

* [Developper guide](dev_guide/0_Abstract.md)
  * [Quickstart](dev_guide/1_Quickstart.md)
  * [Project architecture](dev_guide/2_project_architecture.md)
  * [Advanced usage](dev_guide/3_advanced_usage.md)
  * [Customization](dev_guide/4_advanced_customization.md)
  * [Autobuild](dev_guide/5_autobuild.md)
