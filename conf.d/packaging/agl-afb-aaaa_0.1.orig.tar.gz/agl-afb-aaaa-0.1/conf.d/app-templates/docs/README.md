# Introduction

This document explain how to use the CMake templates files and associated
files to ease developement of AGL application.

<br>
<br>
<br>
<br>
<br>

| *Meta* | *Data* |
| -- | -- |
| **Title** | {{ config.title }} |
| **Author** | {{ config.author }} |
| **Description** | {{ config.description }} |
| **Keywords** | {{ config.keywords }} |
| **Language** | English |
| **Published** | Published {{ config.published }} as an electronic book |
| **Updated** | {{ gitbook.time }} |
| **Collection** | Open-source |
| **Website** | [{{ config.website }}]({{ config.website }}) |
