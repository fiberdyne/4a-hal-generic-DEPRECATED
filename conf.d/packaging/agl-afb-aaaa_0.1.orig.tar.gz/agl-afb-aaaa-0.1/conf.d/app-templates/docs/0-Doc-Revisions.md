Document revisions
==================

| Date        | Version | Designation                          | Author                  |
|-------------|---------|--------------------------------------|-------------------------|
| 4 Jul 2017  |   1.0   | Initial release                      | R. Forlot   [ Iot.bzh ] |
